﻿namespace KasaAPP.Core
{
    public static class JwtConfig
    {
        public static string SecretKey = "SecretKeyProvidedByTijanaNestinac123";
        public static string JWTIssuer = "TijanaNestinac";
    }
}
