﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Searches.LogSearches
{
    public class LogSearch : PaginationSearch
    {
        public int UseCaseIndentification { get; set; }
    }
}
