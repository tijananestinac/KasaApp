﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Application.Dto.SubTypesDto
{
    public class RemoveSubTypeDto : DtoBase
    {
        public int IdToRemove { get; set; }
    }
}
